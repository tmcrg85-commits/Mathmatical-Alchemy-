from pathlib import Path
import json
import math
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPTS = ['test_memory.py', 'test_decoder.py', 'test_rewire.py', 'checks.py', 'wave/experiment.py', 'wave/fields.py', 'wave/mixed.py', 'wave/sensitivity.py', 'wave/joint.py']
EXPECTED = ['results.json', 'decoder_results.json', 'rewire.json', 'retune.json', 'wave/tokens.json', 'wave/fields.json', 'wave/mixed.json', 'wave/sensitivity.json', 'wave/joint.json']

def compare(actual, expected, path):
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys(), path
        for k in expected:
            compare(actual[k], expected[k], f"{path}/{k}")
    elif isinstance(expected, list):
        assert len(actual) == len(expected), path
        for i, item in enumerate(expected):
            compare(actual[i], item, f"{path}/{i}")
    elif isinstance(expected, (float, int)):
        assert math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-8), (path, actual, expected)
    else:
        assert actual == expected, path

def main():
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    for script in SCRIPTS:
        print(f"Running {script}", flush=True)
        subprocess.run([sys.executable, ROOT / "work" / script], env=env, cwd=ROOT,
                       check=True, stdout=subprocess.DEVNULL)
    for report in EXPECTED:
        actual = json.loads((ROOT / "work" / report).read_text())
        expected = json.loads((ROOT / "reference" / report).read_text())
        compare(actual, expected, report)
    print("All nine numerical result files matched the published run.")

if __name__ == "__main__":
    main()
