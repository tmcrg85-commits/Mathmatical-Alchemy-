import json
from pathlib import Path
import numpy as np
from itertools import product
from test_memory import K, EPS, streams, interval, SINGLES, DOUBLES, SEEDS_DEV, SEEDS_TEST, run, change

# Independently enumerate four-step state paths and compare the forward calculation.
h=.03
transition=np.full((K,K), h/(K-1)); np.fill_diagonal(transition,1-h)
emission=np.full((K,K), EPS/(K-1)); np.fill_diagonal(emission,1-EPS)
base=np.zeros(K); base[0]=1.
prior=base
evidence=[1,1,1]
mass=np.zeros(K)
for states in product(range(K),repeat=len(evidence)):
    prob=1.
    left=0
    for s,y in zip(states,evidence):
        prob*=transition[left,s]*emission[s,y]
        left=s
    mass[left]+=prob
for y in evidence:
    prior=change(prior,h)*emission[:,y]; prior/=prior.sum()
assert np.allclose(mass/mass.sum(),prior)
p=np.arange(1,9,dtype=float); p/=p.sum()
assert np.allclose(change(change(p,h),EPS), p@transition@emission)
d=.65*np.array([1.,0.])+.35*np.array([0.,1.])
print('geometry',np.linalg.norm(d), 'exact hidden posterior', prior[1])
# Check that a relay lookup reproduces matrix product and a two-step keyed table lookup.
rng=np.random.default_rng(861)
r=np.stack([rng.permutation(K) for _ in range(2)])
room=rng.dirichlet(np.ones(K),size=K)
table={(c,i):r[c,i] for c in range(2) for i in range(K)}
for c,m in enumerate(r):
    assert np.allclose(np.eye(K)[m]@room, [room[table[c,i]] for i in range(K)])
# Refit on an independent development set at each stress hazard using the same grids.
out={}
for h in [.005,.18]:
    dev=streams(SEEDS_DEV,h)
    test=streams(SEEDS_TEST,h)
    summary={}
    scores={}
    for name in ['single','dual','gate']:
        cfg=min([c for c in SINGLES+DOUBLES if c[0]==name],key=lambda c:run(dev,h,c,False)[0].mean())
        scores[name]=run(test,h,cfg)[0]
        summary[name]=[cfg,float(scores[name].mean())]
    summary['gate_minus_dual']=interval(scores['gate']-scores['dual'])
    out[str(h)]=summary
print(json.dumps(out,indent=2))
Path('work/retune.json').write_text(json.dumps(out,indent=2))
