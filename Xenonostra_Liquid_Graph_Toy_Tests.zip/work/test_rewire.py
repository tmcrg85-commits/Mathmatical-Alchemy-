import json
from pathlib import Path
import numpy as np
from test_memory import K, EYE, EPS, change, interval

def main():
    n=128
    steps=160
    warm=20
    rngs=[np.random.default_rng(7000+j) for j in range(n)]
    room=np.stack([r.integers(K,size=K) for r in rngs])
    prob=np.full((n,K,K),1/K)
    shape=(n,K)
    world=np.arange(n)[:,None]
    acc={k:np.zeros(n) for k in ('frozen','hard','soft','oracle','uniform')}
    loss={k:np.zeros(n) for k in acc}
    route_hits={k:0 for k in ('frozen','hard')}
    age=np.full(shape,-1000)
    track={k:[0.,0] for k in range(5)}
    for t in range(steps):
        # Four streams of random draws per world and tick; arrays include all eight objects.
        data=[]
        for r in rngs:
            change_it=r.random(K)<.03
            move=r.integers(1,K,size=K)
            reference=r.integers(K,size=K)
            bad=r.random(K)<EPS
            noise=r.integers(1,K,size=K)
            data.append((change_it,move,reference,bad,noise))
        switched,moves,ref,corrupt,errors=[np.stack(x) for x in zip(*data)]
        switched=switched.astype(bool)
        age=np.where(switched,0,age+1)
        room=(room+switched*moves)%K
        y=(ref[world,room]+corrupt*errors)%K
        prior=change(prob,.03)
        map_edge=prior.argmax(-1)
        if t==warm:
            fixed=map_edge.copy()
        if t>=warm:
            dense=prior @ EYE[ref]
            beliefs={'frozen':EYE[ref[world,fixed]],'hard':EYE[ref[world,map_edge]],
                     'soft':dense,'oracle':EYE[ref[world,room]],'uniform':np.full_like(dense,1/K)}
            for name,belief in beliefs.items():
                q=change(belief,EPS)
                hit=np.take_along_axis(q,y[...,None],-1)[...,0]
                loss[name]-=np.log(hit).mean(-1)
                mask=np.abs(q-q.max(-1,keepdims=True))<1e-12
                acc[name]+=((mask*EYE[y]).sum(-1)/mask.sum(-1)).mean(-1)
            for name,est in [('frozen',fixed),('hard',map_edge)]:
                route_hits[name]+=(est==room).sum()
            for a,v in track.items():
                which=(age==a)
                v[0]+=((map_edge==room)&which).sum()
                v[1]+=which.sum()
        like=np.where(ref[:,None,:]==y[:,:,None],1-EPS,EPS/(K-1))
        posterior=prior*like
        prob=posterior/posterior.sum(-1,keepdims=True)
    rounds=steps-warm
    out={k:[float(np.mean(loss[k])/rounds),float(np.mean(acc[k])/rounds)] for k in acc}
    out['edge_recovery']={k:float(hits/(rounds*n*K)) for k,hits in route_hits.items()}
    out['age_accuracy']={k:[float(s/m),int(m)] for k,(s,m) in track.items()}
    out['soft_minus_hard']=interval((loss['soft']-loss['hard'])/rounds)
    Path('work/rewire.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
if __name__=='__main__':
    main()
