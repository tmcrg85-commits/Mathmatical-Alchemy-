import json
from pathlib import Path
import numpy as np
from experiment import interval
N=16
def lap(x):
    return 2*x-np.roll(x,-1,axis=-1)-np.roll(x,1,axis=-1)
def sample(n,seed,mode,noise):
    rng=np.random.default_rng(seed)
    pos=rng.integers(N,size=(2,n,1))
    amp=rng.uniform(.7,1.3,size=(2,n,1))
    width=rng.uniform(.55,1.30,size=(2,n,1))
    gap=(np.arange(N)[None,None,:]-pos+N/2)%N-N/2
    waves=amp*np.exp(-.5*(gap/width)**2)
    first,second=waves
    clean=[]
    for t in range(6):
        if mode=='ballistic':
            clean.append(np.roll(first,t,axis=-1)-np.roll(second,-t,axis=-1))
        else:
            clean.append(first-second if not t else clean[-1]-.30*lap(clean[-1]))
    before=clean[0]+noise*rng.normal(size=(n,N))
    now=clean[1]+noise*rng.normal(size=(n,N))
    return before,now,clean[2],clean[5]
def feats(a,b,cols):
    return np.stack([b,lap(b),a][:cols],axis=-1)
def forecast(a,b,col,w):
    for _ in range(4):
        nxt=feats(a,b,col)@w
        a,b=b,nxt
    return b
def metrics(pred,target):
    return np.mean((pred-target)**2,axis=1)
def main():
    out={}
    for i,mode in enumerate(['ballistic','diffusive']):
        a,b,y,_=sample(64,76000+i,mode,.05)
        u,v,_,target=sample(128,77000+i,mode,.05)
        estimates={}
        for k in [2,3]:
            wi=np.linalg.lstsq(feats(a,b,k).reshape(-1,k),y.flatten(),rcond=None)[0]
            estimates['ar'+str(k-1)]=metrics(forecast(u,v,k,wi),target)
        estimates['wave']=metrics(forecast(u,v,3,[2,-1,-1]),target)
        estimates['diff']=metrics(forecast(u,v,2,[1,-.3]),target)
        out[mode]={k:float(x.mean()) for k,x in estimates.items()}
        for k in ('ar1','ar2'):
            out[mode]['wave_minus_'+k]=interval(estimates['wave']-estimates[k])
        a,b,_,y=sample(128,77000+i,mode,0)
        exact=forecast(a,b,3,[2,-1,-1]) if mode=='ballistic' else forecast(a,b,2,[1,-.3])
        assert np.max(abs(exact-y))<1e-12
    print(json.dumps(out,indent=2))
    Path(__file__).with_name('fields.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__': main()
