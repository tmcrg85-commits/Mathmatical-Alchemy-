from pathlib import Path
import json
import numpy as np
from experiment import K,R,LEAK,graph,endpoints,change,EYE,interval

def run(n, seed, switch, rates=None, directional=True):
    rng=np.random.default_rng(seed)
    tag=rng.integers(2,size=(n,R))
    fact=rng.integers(K,size=(n,R))
    previous,current=rng.integers(K,size=(2,n,R))
    fast=np.full((n,R,K),1/K)
    slow=fast.copy()
    gate=np.full((n,R),.5)
    mix=np.linspace(0,1,21)
    fixed=np.zeros((n,len(mix))); adaptive=np.zeros(n)
    oracle=np.zeros(n)
    if rates is not None:
        gates=np.full((n,R,len(rates)),.5)
        losses=np.zeros((n,len(rates)))
    for t in range(160):
        if t%32==0:
            G=graph(n,rng)
        tag^=rng.random((n,R))<switch
        fact=(fact+(rng.random((n,R))<.03)*rng.integers(1,K,size=(n,R)))%K
        report=(fact+(rng.random((n,R))<.15)*rng.integers(1,K,size=(n,R)))%K
        valid,fore,back=endpoints(previous,current,G)
        w=np.where(rng.random((n,R))<np.where(valid,.9,.5),fore,back)
        walk=np.where(rng.random((n,R))<LEAK,rng.integers(K,size=(n,R)),w)
        y=np.where(tag,walk,report)
        wf=np.where(valid,.9*(y==fore)+.1*(y==back),.5*((y==fore)|(y==back)))
        if not directional:
            wf=.5*((y==fore)|(y==back))
        wave=LEAK/K+(1-LEAK)*wf
        p=change(change(.75*fast+.25*slow,.03),.15)
        memory=np.take_along_axis(p,y[...,None],axis=-1)[...,0]
        if rates is not None:
            q=(1-gates)*memory[...,None]+gates*wave[...,None]
            losses-=np.log(q).mean(1)
            gates=rates+(1-2*rates)*gates*wave[...,None]/q
        score=(1-gate)*memory+gate*wave
        fixed-=np.log((1-mix)*memory[...,None]+mix*wave[...,None]).mean(1)
        adaptive-=np.log(score).mean(1)
        oracle-=np.log(np.where(tag,wave,memory)).mean(1)
        # Learner always uses 3% for the switch estimate.
        gate=.03+.94*gate*wave/score
        fast+=.5*(EYE[y]-fast)
        slow+=.15*(current==y)[...,None]*(EYE[y]-slow)
        previous,current=current,y
    if rates is not None:
        return losses/160
    return fixed/160,adaptive/160,oracle/160
def main():
    dev=run(64,78000,.03)[0]
    best=int(dev.mean(0).argmin())
    report={'development_weight':best/20}
    for j,h in enumerate([.03,.18]):
        static,adapt,known=run(128,79000+j,h)
        _,spread,_=run(128,79000+j,h,directional=False)
        report[str(h)]={'adaptive_diffusion':spread.mean(),'wave_minus_diffusion':interval(adapt-spread),'memory':static[:,0].mean(),'wave':static[:,-1].mean(),
                        'fixed':static[:,best].mean(),'adaptive':adapt.mean(),'known':known.mean(),
                        'difference':interval(adapt-static[:,best])}
    print(json.dumps(report,indent=2))
    Path(__file__).with_name('mixed.json').write_text(json.dumps(report,indent=2))
if __name__=='__main__': main()
