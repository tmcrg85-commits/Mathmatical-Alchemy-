"""Token prediction, evolving search steps, and an out-of-domain memory check."""
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_memory import streams, change, EYE, interval

K, R, T, LEAK = 8, 8, 96, .08
ETAS = np.geomspace(.005,.8,17)
GEN, LINES, BATCH, AUDIT = 8, 40, 4, 16
def graph(n,rng):
    order=rng.random((n,K)).argsort(axis=1)
    inv=order.argsort(axis=1)
    right, left = (np.take_along_axis(order,(inv+d)%K,axis=1) for d in (1,-1))
    return right,left
def endpoints(prev,cur,graph_pair):
    plus,minus = (np.take_along_axis(a,cur,axis=1) for a in graph_pair)
    valid=(prev==plus)|(prev==minus)
    forward=np.where(prev==plus,minus,plus)
    backward=np.where(prev==plus,plus,minus)
    return valid,forward,backward
def simulate(n,seed,h=.03,mode=None):
    rng=np.random.default_rng(seed)
    regime=rng.integers(2,size=(n,R))
    prev,cur=rng.integers(K,size=(2,n,R))
    out=[]
    for t in range(T):
        if t%32==0:
            g=graph(n,rng)
        valid,forward,back=endpoints(prev,cur,g)
        regime ^= rng.random((n,R))<h
        q=np.where(regime,.9,.1) if mode is None else mode
        p=np.where(valid,q,.5)
        physical=np.where(rng.random((n,R))<p,forward,back)
        y=np.where(rng.random((n,R))<LEAK,rng.integers(K,size=(n,R)),physical)
        out.append((valid,forward==y,back==y))
        prev,cur=cur,y
    return np.array(out)
def rates_loss(data,rates):
    _,_,n,r=data.shape
    q=np.full((len(rates),n,r),.5)
    losses=np.zeros((len(rates),n))
    for valid,fore,back in data:
        value=np.where(valid,q*fore+(1-q)*back,.5*(fore|back))
        loss=-np.log(LEAK/K+(1-LEAK)*value)
        losses+=loss.mean(axis=-1)
        eligible=valid&(fore|back)
        q=np.clip(q+rates[:,None,None]*eligible*(fore-q),.02,.98)
    return (losses/T).T
def fixed(data,q):
    valid,fore,back=data.transpose((1,0,2,3))
    p=np.where(valid,q*fore+(1-q)*back,.5*(fore|back))
    return -np.log(LEAK/K+(1-LEAK)*p).mean(axis=(0,2))
def bayes(data,h):
    # The latent state is whether transport currently favors forward moves.
    pi=np.full(data.shape[2:],.5)
    loss=np.zeros(data.shape[2])
    for valid,fore,back in data:
        prior=(1-h)*pi+h*(1-pi)
        def like(q):
            return LEAK/K+(1-LEAK)*np.where(valid,q*fore+(1-q)*back,.5*(fore|back))
        high,low=like(.9),like(.1)
        marginal=prior*high+(1-prior)*low
        loss-=np.log(marginal).mean(axis=-1)
        pi=prior*high/marginal
    return loss/T

def bridge_test():
    results={}
    for g,mode in enumerate([.9,.5,.1]):
        dat=simulate(128,63000+g,mode=mode)
        d,w=fixed(dat,.5),fixed(dat,.9)
        results[str(mode)]={'spread':d.mean(),'wave':w.mean(),'difference':interval(w-d)}
    # Exhaustive vector vs incoming-edge identity on one cycle, including ties and jumps.
    G=graph(1,np.random.default_rng(77))
    A=np.zeros((K,K))
    for i in range(K):
        A[i,[G[0][0,i],G[1][0,i]]]=1
    for p in range(K):
        for c in range(K):
            v,f,b=endpoints(np.array([[p]]),np.array([[c]]),G)
            rect=np.maximum(EYE[c]@A-EYE[p],0.)
            rect/=rect.sum()
            W=EYE[int(f.item())] if v.item() else .5*(EYE[int(f.item())]+EYE[int(b.item())])
            assert np.allclose(rect,W)
    return results

def inheritance():
    fit=simulate(256,74000)
    dev_best=int(rates_loss(fit,ETAS).mean(0).argmin())
    validation=[]
    for g in range(GEN):
        dat=simulate(LINES*BATCH,71000+g)
        validation.append(rates_loss(dat,ETAS).reshape(LINES,BATCH,-1).mean(1))
    def audit(h,seed):
        data=simulate(LINES*AUDIT,seed,h)
        return (rates_loss(data,ETAS).reshape(LINES,AUDIT,-1).mean(1),
                bayes(data,h).reshape(LINES,AUDIT).mean(1))
    primary,oracle=audit(.03,72000)
    shifted,oracle_s=audit(.18,73000)
    idx=np.arange(LINES)
    trace={}
    rng=np.random.default_rng(75000)
    decisions=rng.choice([-1,0,1],size=(GEN,LINES,2))
    for kind in ('fixed1','fixed2','self','fixed4'):
        j=np.zeros(LINES,dtype=int)
        scale=np.ones(LINES,dtype=int)*(1 if kind=='fixed2' or kind=='self' else 2 if kind=='fixed4' else 0)
        history=[j.copy()]
        step_hist=[scale.copy()]
        for g in range(GEN):
            step=np.repeat(scale[:,None],2,axis=1)
            if kind=='self':
                step=np.clip(step+decisions[g],0,2)
            offsets=(2**step)*np.array([-1,1])
            proposal=np.column_stack([j,np.clip(j[:,None]+offsets,0,len(ETAS)-1)])
            all_scales=np.column_stack([scale,step])
            winner=np.take_along_axis(validation[g],proposal,axis=1).argmin(1)
            j=proposal[idx,winner]
            scale=all_scales[idx,winner]
            history.append(j.copy())
            step_hist.append(scale.copy())
        trace[kind]=[np.array(history),np.array(step_hist)]
    output={'grid':ETAS.tolist(),'dev_best':dev_best,'learning_curves':{}, 'primary':{},'shift':{}}
    for kind,(hist,scales) in trace.items():
        output['learning_curves'][kind]=[float(primary[idx,j].mean()) for j in hist]
    for name,risks,ref in [('primary',primary,oracle),('shift',shifted,oracle_s)]:
        scores={k:risks[idx,his[-1]] for k,(his,scales) in trace.items()}
        scores.update(start=risks[:,0],grid=risks[:,dev_best],bayes=ref)
        output[name]={k:float(v.mean()) for k,v in scores.items()}
        output[name]['self_minus']={k:interval(scores['self']-v) for k,v in scores.items() if k!='self'}
    output['scale_changes']=int((trace['self'][1][1:]!=trace['self'][1][:-1]).sum())
    return output

def original(seeds):
    obs=streams(seeds,.03);n=len(seeds)
    rng=np.random.default_rng(66911)
    G=graph(n,rng)
    weights=np.array([0,.05,.10,.25,.50,.75,1])
    losses=np.zeros((n,len(weights)))
    fast=np.full((n,K,K),1/K);slow=fast.copy()
    prev=np.full((n,K),-1);prev2=prev.copy()
    for t,y in enumerate(obs):
        prior=change(change(.75*fast+.25*slow,.03),.15)
        baseline=np.take_along_axis(prior,y[...,None],axis=-1)[...,0]
        wp=baseline
        if t>=2:
            valid,fore,back=endpoints(prev2,prev,G)
            wave=np.where(valid,.9*(fore==y)+.1*(back==y),.5*((fore==y)|(back==y)))
            wp=LEAK/K+(1-LEAK)*wave
        q=(1-weights)*baseline[...,None]+weights*wp[...,None]
        losses-=np.log(q).mean(1)
        truth=EYE[y]
        fast+=.5*(truth-fast)
        slow+=.15*(prev==y)[...,None]*(truth-slow)
        prev2,prev=prev,y
    return weights,losses/len(obs)

def orig_result():
    weights,dev=original(range(61000,61032))
    _,test=original(range(62000,62128))
    i=int(dev.mean(0).argmin())
    return {'weights':weights.tolist(),'best':i,'test':test.mean(0).tolist(),'forced_minus_base':interval(test[:,3]-test[:,0])}

if __name__=='__main__':
    d={'bridge':bridge_test(),'inherit':inheritance(),'original':orig_result()}
    dest=Path(__file__).with_name('tokens.json')
    dest.write_text(json.dumps(d,indent=2))
    print(dest.read_text())
