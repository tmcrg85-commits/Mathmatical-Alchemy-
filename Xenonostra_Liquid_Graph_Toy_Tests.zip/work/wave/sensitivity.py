import numpy as np
import json
from pathlib import Path
from experiment import LINES,BATCH,AUDIT,GEN,ETAS,rates_loss,simulate,fixed,interval
idx=np.arange(LINES)
rng=np.random.default_rng(81000)
initial=rng.integers(len(ETAS),size=LINES)
decisions=rng.choice([-1,0,1],size=(GEN,LINES,2))
def choice(g):
    return rates_loss(simulate(LINES*BATCH,82000+g),ETAS).reshape(LINES,BATCH,-1).mean(1)
dev=[choice(g) for g in range(GEN)]
data=simulate(LINES*AUDIT,83000)
test=rates_loss(data,ETAS).reshape(LINES,AUDIT,-1).mean(1)
risks={'start':test[idx,initial], 'diffusion':fixed(data,.5).reshape(LINES,AUDIT).mean(1)}
for name,step0 in [('fixed1',0),('fixed2',1),('fixed4',2),('self',1)]:
    j=initial.copy()
    s=np.full(LINES,step0)
    for g in range(GEN):
        sc=np.repeat(s[:,None],2,axis=1)
        if name=='self':sc=np.clip(sc+decisions[g],0,2)
        offsets=2**sc*np.array([-1,1])
        proposals=np.column_stack((j,np.clip(j[:,None]+offsets,0,16)))
        scale=np.column_stack((s,sc))
        best=np.take_along_axis(dev[g],proposals,axis=1).argmin(1)
        j,s=proposals[idx,best],scale[idx,best]
    risks[name]=test[idx,j]
out={k:v.mean() for k,v in risks.items()}
out['self_minus']={k:interval(risks['self']-v) for k,v in risks.items() if k!='self'}
print(json.dumps(out,indent=2))
Path(__file__).with_name('sensitivity.json').write_text(json.dumps(out,indent=2))
