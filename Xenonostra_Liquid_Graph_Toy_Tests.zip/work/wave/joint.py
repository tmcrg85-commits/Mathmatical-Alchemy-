import json
from pathlib import Path
import numpy as np
from experiment import ETAS,GEN,LINES,BATCH,AUDIT,interval
from mixed import run
def main():
    ix=np.arange(LINES)
    grid=int(run(256,84000,.03,ETAS).mean(0).argmin())
    train=[run(LINES*BATCH,85000+g,.03,ETAS).reshape(LINES,BATCH,-1).mean(1) for g in range(GEN)]
    test=run(LINES*AUDIT,86000,.03,ETAS).reshape(LINES,AUDIT,-1).mean(1)
    shift=run(LINES*AUDIT,87000,.18,ETAS).reshape(LINES,AUDIT,-1).mean(1)
    delta=np.random.default_rng(88000).choice([-1,0,1],size=(GEN,LINES,2))
    result={'grid':float(ETAS[grid]),'curves':{},'test':{},'shift':{}}
    states={}
    for name,sc0 in [('fixed1',0),('fixed2',1),('fixed4',2),('self',1)]:
        j=np.zeros(LINES,dtype=int);s=np.full(LINES,sc0)
        history=[j.copy()]
        for g in range(GEN):
            child_sc=np.repeat(s[:,None],2,axis=1)
            if name=='self': child_sc=np.clip(child_sc+delta[g],0,2)
            cand=np.column_stack((j,np.clip(j[:,None]+np.array([-1,1])*2**child_sc,0,16)))
            all_sc=np.column_stack((s,child_sc))
            best=np.take_along_axis(train[g],cand,axis=1).argmin(1)
            j,s=cand[ix,best],all_sc[ix,best]
            history.append(j.copy())
        states[name]=j
        result['curves'][name]=[float(test[ix,x].mean()) for x in history]
    for label,data in [('test',test),('shift',shift)]:
        risks={k:data[ix,j] for k,j in states.items()}|{'grid':data[:,grid],'start':data[:,0]}
        result[label]={k:float(v.mean()) for k,v in risks.items()}
        result[label]['self_minus_fixed2']=interval(risks['self']-risks['fixed2'])
        result[label]['self_minus_grid']=interval(risks['self']-risks['grid'])
    print(json.dumps(result,indent=2))
    Path(__file__).with_name('joint.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
