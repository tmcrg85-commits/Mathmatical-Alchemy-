from pathlib import Path
import json
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp
from test_memory import K, EYE, N_STEPS, streams, interval

E, _ = np.linalg.qr(np.random.default_rng(403).normal(size=(K,K)))
U = np.eye(2*K)
def make(start, count):
    observations=streams(range(start,start+count), .03)
    worlds = np.arange(count)[:,None]
    room = np.arange(K)
    keys = np.empty_like(observations)
    perm = np.empty_like(observations)
    for j in range(count):
        rng = np.random.default_rng(50000+start+j)
        routes = np.stack([rng.permutation(K) for _ in range(2)])
        inverse = np.argsort(routes, axis=1)
        for t in range(N_STEPS):
            ctx = rng.integers(2,size=K)
            obj = inverse[ctx,room]
            keys[t,j] = K*ctx + obj
            assert np.array_equal(routes[ctx,obj],room)
            perm[t,j] = rng.permutation(K)
    features={}
    for name, size in [('phrase', 2*K),('graph', K)]:
        f=np.full((count,size,K),1/K)
        s=f.copy()
        prev=np.full((count,size),-1)
        feature=np.empty((*observations.shape,K))
        for t,y in enumerate(observations):
            index = keys[t] if name=='phrase' else room[None,:]
            old_f, old_s = f[worlds,index], s[worlds,index]
            feature[t] = (.75*old_f + .25*old_s) @ E
            target = EYE[y]
            f[worlds,index] = old_f + .50*(target-old_f)
            s[worlds,index] = old_s + .15*((y==prev[worlds,index])[...,None])*(target-old_s)
            prev[worlds,index] = y
        features[name] = feature
    features['shuffled']=np.take_along_axis(features['graph'],perm[...,None],axis=2)
    p=U[keys]
    def flatten(x):
        return x.reshape(-1,x.shape[-1])
    return {k:flatten(np.concatenate((p,v),axis=-1)) for k,v in features.items()} | {'prefix':flatten(p)}, observations

def fit(x,y):
    onehot=EYE[y]
    def objective(v):
        w=v.reshape(-1,K)
        logits=x@w
        logp=logits-logsumexp(logits,axis=1)[:,None]
        value=-logp[np.arange(len(y)),y].mean() + .5e-4*(w*w).sum()
        grad=x.T@(np.exp(logp)-onehot)/len(y) + 1e-4*w
        return value,grad.ravel()
    result=minimize(objective,np.zeros(x.shape[1]*K),jac=True,method='L-BFGS-B',
                    options={'maxiter':300,'ftol':1e-13,'gtol':1e-8})
    assert result.success,(result.message,abs(result.jac).max())
    return result.x.reshape(-1,K)

def evaluate(x,w,obs):
    logits=x@w
    logp=logits-logsumexp(logits,axis=1)[:,None]
    loss=-logp[np.arange(len(x)),obs.ravel()].reshape(obs.shape).mean(axis=(0,2))
    acc=(logp.argmax(-1)==obs.ravel()).reshape(obs.shape).mean(axis=(0,2))
    return loss,acc

def main():
    train, train_y=make(3000,64)
    test, test_y=make(5000,128)
    raw={}
    for k in ['prefix','phrase','graph']:
        head=fit(train[k],train_y.ravel())
        raw[k]=evaluate(test[k],head,test_y)
        if k=='graph':
            raw['shuffled']=evaluate(test['shuffled'],head,test_y)
    result={k:[float(v[0].mean()),float(v[1].mean())] for k,v in raw.items()}
    result['graph_minus_phrase']=interval(raw['graph'][0]-raw['phrase'][0])
    Path('work/decoder_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
