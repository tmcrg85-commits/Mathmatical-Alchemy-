from pathlib import Path
import json
import numpy as np

K = 8
EYE = np.eye(K)
N_STEPS = 160
EPS = 0.15
SEEDS_DEV = range(32)
SEEDS_TEST = range(1000, 1128)
HAZARDS = [0.005, 0.03, 0.18]
SINGLES = [("single", a) for a in (0.05, 0.15, 0.30, 0.50, 0.70, 0.90)]
DOUBLES = [(kind, f, s, w) for kind in ("dual", "gate")
           for f in (0.50, 0.80) for s in (0.05, 0.15) for w in (0.25, 0.50, 0.75)]
FIXED = [("uniform",), ("frozen",), ("latest",), ("bayes",)]

def structural():
    totals = dict(clean=[], blind=[], shuffle=[])
    dims = ["2", "4", "8", "orth"]
    hits = {d: np.zeros(3, dtype=int) for d in dims}
    for seed in range(256):
        rng = np.random.default_rng(20000 + seed)
        route = EYE[np.stack([rng.permutation(K) for _ in range(2)])]
        emission = EYE[rng.permutation(K)]
        code, _ = np.linalg.qr(rng.normal(size=(K, K)))
        pure = route @ emission
        label = pure.argmax(axis=-1)
        assert np.allclose(pure @ code @ code.T, pure)
        totals["clean"].append(((pure @ code @ code.T).argmax(-1) == label).mean())
        blind = pure.mean(0)
        peaks = blind == blind.max(-1, keepdims=True)
        totals["blind"].append(np.take_along_axis(peaks[None,:,:] / peaks.sum(-1)[None,:,None],
                                                label[:,:,None],axis=-1).mean())
        broken = route @ emission[rng.permutation(K)]
        totals["shuffle"].append((broken.argmax(-1) == label).mean())
        mix = .65 * pure[0] + .35 * pure[1]
        distinct = label[0] != label[1]
        for d in dims:
            if d == "orth":
                embed = code
            else:
                embed = rng.normal(size=(K, int(d)))
                embed /= np.linalg.norm(embed, axis=1, keepdims=True)
            pred = (mix @ embed @ embed.T).argmax(-1)
            third = (pred != label[0]) & (pred != label[1])
            hits[d] += [distinct.sum(), ((pred == label[0]) & distinct).sum(),
                        (third & distinct).sum()]
    return {**{k:np.mean(v) for k,v in totals.items()}, "mixtures": {d:v.tolist() for d,v in hits.items()}}

def streams(seeds, hazard):
    obs = np.empty((N_STEPS,len(seeds),K),int)
    for w,seed in enumerate(seeds):
        rng = np.random.default_rng(seed)
        state = rng.integers(K, size=K)
        for t in range(N_STEPS):
            switch = rng.random(K) < hazard
            delta = rng.integers(1,K,size=K)
            state = (state + switch * delta) % K
            corrupt = rng.random(K) < EPS
            noise = rng.integers(1,K,size=K)
            obs[t,w] = (state + corrupt * noise) % K
    return obs

def change(x, rate):
    return (1-rate)*x + rate*(1-x)/(K-1)

def run(obs, hazard, config, full=True):
    steps, worlds, rooms = obs.shape
    fast = np.full((worlds,rooms,K),1/K)
    slow = fast.copy()
    prev = np.full((worlds,rooms),-1)
    name = config[0]
    losses, correct = np.zeros(worlds), np.zeros(worlds)
    for t,y in enumerate(obs):
        if name in ("dual","gate"):
            _, f, s, w = config
            belief = w*fast + (1-w)*slow
        else:
            belief = fast
        prior = change(belief,hazard)
        score = change(prior,EPS)
        truth = EYE[y]
        assigned = np.take_along_axis(score,y[...,None],-1)[...,0]
        losses -= np.log(assigned).mean(axis=1)
        if full:
            peaks = np.abs(score-score.max(axis=-1,keepdims=True)) <= 1e-12
            correct += ((peaks*truth).sum(-1)/peaks.sum(-1)).mean(axis=1)
        if name == "bayes":
            like = np.where(truth != 0,1-EPS,EPS/(K-1))
            fast = prior*like / assigned[...,None]
        elif name == "single":
            fast += config[1]*(truth-fast)
        elif name in ("dual","gate"):
            fast += f*(truth-fast)
            rate = s if name == "dual" else s*(prev==y)[...,None]
            slow += rate*(truth-slow)
        elif name == "latest" or (name == "frozen" and t==0):
            fast = truth
        prev = y
    return losses/steps, correct/steps

def summarize(v):
    return float(np.mean(v))

def interval(d):
    boot = np.random.default_rng(712).choice(d,size=(10000,len(d)),replace=True).mean(axis=1)
    return [float(np.mean(d)),*np.percentile(boot,[2.5,97.5]).tolist()]

def experiment():
    dev = streams(SEEDS_DEV,0.03)
    cfg = {}
    for kind in ("single","dual","gate"):
        candidates = [c for c in SINGLES+DOUBLES if c[0]==kind]
        cfg[kind] = min(candidates, key=lambda c: np.mean(run(dev,.03,c,False)[0]))
    result={"settings":cfg, "A":structural(), "B":{}}
    for h in HAZARDS:
        obs = streams(SEEDS_TEST,h)
        raw={c[0]:run(obs,h,c) for c in [*FIXED,*cfg.values()]}
        summary={k:[summarize(l),summarize(a)] for k,(l,a) in raw.items()}
        for rival in ["dual","single","bayes"]:
            summary["gate_minus_"+rival]=interval(raw["gate"][0]-raw[rival][0])
        result["B"][str(h)] = summary
    return result

def audit():
    h=.03
    p=EYE[0]
    path=[]
    for step in range(4):
        prior=change(p,h)
        score=change(prior,EPS)
        path.append([p[0],p[1],score[0],score[1]])
        p = prior*(EYE[1]*(1-EPS)+(1-EYE[1])*EPS/(K-1))/score[1]
        assert np.isclose(p.sum(),1.)
    return path

if __name__ == "__main__":
    out=experiment()
    out["contradiction"]=audit()
    Path("work/results.json").write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
