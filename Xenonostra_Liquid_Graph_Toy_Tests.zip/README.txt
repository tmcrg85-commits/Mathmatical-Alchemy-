What Should Stick in a Liquid AI Memory?
Reproduction files for the Xenonostra’ paper

Extract the ZIP. In an environment with Python 3.12, NumPy 2.3.5, and SciPy 1.17.0, run

    python run_all.py

The scripts use generated data and run on CPU. They write new JSON results under work/.
The runner compares those results with the saved values in reference/ and reports any mismatch.
The decoder may give slightly different numerical results with different BLAS or library versions.

The first four scripts reproduce the original changing-memory and routing tests.
wave/fields.py compares wave, diffusion and learned graph autoregressions.
wave/experiment.py checks discrete routing, original-benchmark transfer and inherited learning rates.
wave/mixed.py compares fixed and adaptive combinations of the original memory and directional readout.
wave/sensitivity.py checks the directional learner from randomized initial settings.
wave/joint.py applies inherited updates to the switching rate of the combined model.
All metrics and keys in reference/ are populated by the scripts.
